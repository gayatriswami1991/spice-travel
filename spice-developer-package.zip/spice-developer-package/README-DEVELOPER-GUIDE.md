# Spice Travel: Ad Landing Page, Developer Guide

Publish one Divi page and connect its lead tracking. About 1 to 2 hours.

## 1. Page settings

| Field | Value |
| --- | --- |
| URL | https://spicetravel.co.ke/best-travel-agent-nairobi/  (slug: best-travel-agent-nairobi) |
| Page title (admin) | Best Corporate Travel Agent in Nairobi |
| Meta title (58/60) | Corporate Travel Agent Nairobi \| Christmas, New Year Deals |
| Meta description (150/160) | IATA-certified travel agent in Nairobi. Christmas and New Year packages, festive flights and year-end corporate retreats. Free quote, call back today! |
| Canonical | https://spicetravel.co.ke/best-travel-agent-nairobi/ (itself) |
| Robots | noindex, follow |
| Open Graph title / description | same as meta title / description |
| Open Graph + Twitter image | https://spicetravel.co.ke/wp-content/uploads/2026/11/hero-tented-suite.webp (upload `images/hero-tented-suite.webp` first; 1200 x 630 is ideal) |
| H1 | Best Corporate Travel Agent in Nairobi (set by the page script; changes with ?s=) |

Set the meta fields in Yoast (SEO title, meta description, Advanced: robots, canonical, social tab for Open Graph).
Divi's code module cannot write to the page head. If Yoast is not available, paste `seo/seo-head.html` into the head with WPCode (page-specific).

Why noindex: this is an ad page. Indexing it would compete with /corporate-travel-management/ for the same searches.
If the owner later wants it to rank in Google search, set "index, follow" and tell the SEO person (the pages would then overlap).

After the festive season (10 Jan 2027) change the meta title and description to a year-round version, for example:
"Corporate Travel Agent Nairobi | Free Quote | Spice Travel" and
"IATA-certified since 1994 and rated 5 on Google. Corporate travel, flight booking and holiday packages in Nairobi. Get a free quote and call back today!"
The Christmas and New Year section and the festive ribbon hide themselves on 10 Jan 2027 (no action needed).

## 2. Install (Divi)

1. Pages > Add New. Title "Best Corporate Travel Agent in Nairobi". Slug `best-travel-agent-nairobi`. Full-width or blank template.
2. Open Divi Builder. Add one Fullwidth section with one Fullwidth Code module.
3. Paste the whole content of `page/1-PASTE-THIS-in-Divi-images-embedded.html` into the module. Do not edit it. Paste only inside the module, not in the Visual or Text editor of the page.
4. The site's global header and footer stay as they are. The page has no menu or footer of its own.
5. Set the Yoast fields (section 1). Publish. Clear all caches (Divi static CSS, cache plugin, CDN).

Light version (recommended after launch, loads faster): upload everything in `images/` to the Media Library, replace every `assets/` in `page/2-LIGHT-version-upload-images-first.html` with the uploads URL (for example `https://spicetravel.co.ke/wp-content/uploads/2026/11/`), and paste that file instead.

If images do not show on the live page:
- Turn off Smush lazy load for this page (every image already has the class `skip-lazy`, `data-no-lazy` and `data-skip-lazy`).
- Exclude the page from image optimisation, WebP conversion, minify and "delay JavaScript" in the cache plugin.
- Look for blocked requests or Content Security Policy errors in the browser console.
- If a plugin strips long `data:` strings, use the light version with Media Library images.
Do not add extra wpautop or shortcode filters to this module. The CSS and JavaScript contain no ampersand characters on purpose, because WordPress rewrites them.

## 3. Schema markup

Already inside the page code (top of the file, one JSON-LD block). Also saved as `seo/schema.jsonld` for validation.
Types: WebPage, BreadcrumbList, TravelAgency + LocalBusiness (Spice Travel Ltd: logo, phone, email, Westlands address, opening hours Mon-Fri 8:30-17:30 and Sat 8:30-13:00, social profiles, founded 1994), 3 x Service (corporate travel management, flight booking, holiday and safari packages), FAQPage (the 12 questions shown on the page, word for word).

Checks:
- Validate with validator.schema.org and Google's Rich Results Test. Expect no errors.
- If Yoast already outputs an Organization / LocalBusiness block, two business blocks can appear. Our id is https://spicetravel.co.ke/#organization. If Yoast uses the same id, delete the TravelAgency object from this page.
- Review stars are NOT included on purpose (Google does not show stars for a business's own reviews; adding them risks a penalty).
- Optional later: add `geo` and `priceRange`.

## 4. Forms (no new form needed)

The 3-step form and two quick "name + phone" forms fill and submit the existing Contact Form 7 form id 1438 through a hidden shortcode `[contact-form-7 id="1438"]` at the bottom of the page code.

Form 1438 must have fields named exactly: Name, Email, Phone, Service, Message.
Service dropdown values: Flight Booking, Safari & Wildlife Tour, Holiday Package, Visa Assistance, Hotel Reservation, Group Travel, Other.
Mail template must print [Phone] and [Message].

Every lead's Message starts with "BEST LANDING PAGE" and a REQUEST TYPE line (CORPORATE OR GROUP TRAVEL, FLIGHT TICKETS, HOLIDAY PACKAGE, VISA OR OTHER HELP), plus the phone, page and UTM / gclid values.

Email: CF7 requires Email, but the page lets people leave it empty. The script then fills noemail@spicetravel.co.ke (constant QUICK_EMAIL in the script) and writes "No email given: please CALL this number". Better: make Email optional in form 1438 and set QUICK_EMAIL to ''. (Form 1438 is also used on the home page.)

## 5. Tracking (Google Tag Manager)

GTM-5T5QFFC3 is already on the site. A second container GTM-T9598QF also loads: check both for an existing conversion tag so leads are not counted twice.

On a sent lead (CF7 event wpcf7mailsent) the page pushes to the dataLayer:
  { event: "generate_lead", page: "best_landing", intent: "corporate|agent|flights|packages",
    lead_type: "callback_corporate|callback_flights|callback_packages|callback_other|quick_callback",
    source: "step_form|mid|final", need: "...", package: "..." }
Other events: form_start, form_step (1 to 3), cta_click, package_click.

Setup:
1. Trigger: Custom Event "generate_lead".
2. Tag: GA4 event "generate_lead" with parameters intent, lead_type, source. Mark it a key event in GA4.
3. Tag: Google Ads conversion (ID and label from the ad person). Primary, count "One".
4. Test in GTM Preview: one lead from the step form and one from a quick form. Each must fire once.

UTM template (set in Google Ads, not on the page):
{lpurl}?utm_source=google&utm_medium=cpc&utm_campaign={campaignid}&utm_term={keyword}&utm_content={adgroupid}
Auto-tagging must be on so gclid is added.

## 6. Final URLs for the ad groups

| Ad group | Final URL | H1 shown |
| --- | --- | --- |
| Corporate (default) | https://spicetravel.co.ke/best-travel-agent-nairobi/ | Best Corporate Travel Agent in Nairobi |
| Travel agent (generic) | https://spicetravel.co.ke/best-travel-agent-nairobi/?s=agent | Best Travel Agent in Nairobi |
| Flights | https://spicetravel.co.ke/best-travel-agent-nairobi/?s=flights | Flight Booking Agent in Nairobi |
| Holiday packages | https://spicetravel.co.ke/best-travel-agent-nairobi/?s=packages | Holiday Packages from Nairobi |

Section anchors: #sl-corporate, #sl-flights, #sl-packages, #sl-offers, #sl-retreats, #sl-festive, #sl-form.
Keyword plan for the ad person: `seo/ad-keywords-and-urls.md`.

## 7. Test checklist before launch

- [ ] The 4 URLs above open and the H1 changes.
- [ ] View-source shows the right title, description, canonical, robots.
- [ ] Schema passes the Rich Results Test and Schema Markup Validator.
- [ ] All images show: hero slideshow, 4 package categories, gallery, banner band, Christmas section.
- [ ] Test lead from the step form reaches the inbox with Name, Email, Phone, Service, Message.
- [ ] Test lead from a quick form (name and phone only) reaches the inbox.
- [ ] generate_lead fires once per lead in GTM Preview and GA4 DebugView.
- [ ] Phone: sticky "Request a Call Back" bar shows, no horizontal scroll, forms usable.
- [ ] Mobile PageSpeed score noted (target LCP under 3 s).
- [ ] Offer cards with an end date hide themselves after 19 Dec 2026 (automatic).
- [ ] Privacy Policy and Terms pages exist (footer links are still "#"; ads policies expect a privacy policy).

## 8. Open questions for the owner (not for the developer to decide)

- Confirm all package prices (source: Instagram posters). JW Marriott: KES 68,000 or 71,000. Ritz-Carlton: USD 1,950 or 2,500 per night. Mauritius and Seychelles show "Ask for today's rate".
- Confirm Christmas in Dubai 2026 dates and price, and the Mara and Watamu offer validity.
- Confirm photos for Soroi Amboseli, Ritz-Carlton, Suyian and JW Marriott are the right properties (matched by appearance).
- Surana name: poster says "Surana Mara Camp", notes say "Surana Ilara Camp".
- Confirm the "same day quote" promise and the office hours.
- Known limit: the headline changes through JavaScript, so a crawler that does not run scripts sees the default corporate headline.
- Not yet tested on the live site, only in a browser preview with a stub form.

Online copy of this guide: https://claude.ai/artifact/CTiLyfPyb54FEEAbE3VU7s
